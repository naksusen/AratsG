/**
 * @format
 * @type {import('tailwindcss').Config}
 */

module.exports = {
  content: [],
  theme: {
    extend: {},
  },
  plugins: [require("tailwind-scrollbar")],
};

module.exports = {
  // ...
  plugins: [
    // ...
    require("tailwind-scrollbar"),
  ],
};
